using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    public GameObject spawnLargeBall;
    float initialDelay = 2, repeatInterval = 30;
    public float spawnPosX , spawnPosY ;
    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("SpawnLargeBall", initialDelay, repeatInterval);
    }

    void SpawnLargeBall()
    {
        spawnPosX = Random.Range(-6f, 6f);
        spawnPosY = Random.Range(2f, 3.2f);

        spawnLargeBall.gameObject.GetComponent<BallMoving>().ballSize = Random.Range(2f, 2.5f);
        // Spawaned Force direction
        if (spawnPosX < 0)
        {
            spawnLargeBall.gameObject.GetComponent<BallMoving>().forceDirection = 1f;
        }
        else
        { spawnLargeBall.gameObject.GetComponent<BallMoving>().forceDirection = -1f; }
        // Instantiate
        Instantiate(spawnLargeBall, new Vector3(spawnPosX, spawnPosY, 0), spawnLargeBall.transform.rotation);
        
    }
}
