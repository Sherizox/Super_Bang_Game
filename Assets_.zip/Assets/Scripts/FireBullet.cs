using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireBullet : MonoBehaviour
{
    public GameObject[] ballSpawn;
    public float bulletSpeed = 10;

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        if (gameObject.transform.position.y < 0)
        {
            gameObject.transform.Translate(Vector3.up * Time.deltaTime * bulletSpeed);
        }
        else
        {
            Destroy(gameObject, 0.1f);
        }

    }
    void Spawning(int _index,Vector3 _position, Quaternion _rotation)
    {
        // left ball
        ballSpawn[_index].gameObject.GetComponent<BallMoving>().forceDirection = -1f;
        Instantiate(ballSpawn[_index], _position, _rotation);
        // right ball
        ballSpawn[_index].gameObject.GetComponent<BallMoving>().forceDirection = 1f;
        Instantiate(ballSpawn[_index], _position, _rotation);
    }
    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        ++UiManager.score;
        switch (collision.gameObject.name)
            {
            case "LargeBall(Clone)":
                 Destroy(collision.gameObject,0.01f);
                 Spawning(0, collision.gameObject.transform.position, collision.gameObject.transform.rotation);
                 break;

            case "MediumBall(Clone)":
                Destroy(collision.gameObject);
                Spawning(1, collision.gameObject.transform.position, collision.gameObject.transform.rotation);

                break;

            case "SmallBall(Clone)":
                Destroy(collision.gameObject);
                Spawning(2, collision.gameObject.transform.position, collision.gameObject.transform.rotation);

                break;

            case "TinyBall(Clone)":
                Destroy(collision.gameObject);
                break;

            default:
                    break;
            }

           
        
        Destroy(gameObject,0.01f);
    }
}
