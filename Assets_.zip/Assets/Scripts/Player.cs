using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    float horizontalInput;
    public GameObject firedBullet;
    private Sprite idleSprite;
    public float speedPlayer=10.0f;

    private Animator playerAnimator;
    bool isHitedPlayer;
    // Start is called before the first frame update
    void Start()
    {
        playerAnimator=GetComponent<Animator>();
        playerAnimator.SetBool("idle_b", true);
        

    }

    // Update is called once per frame
    void Update()
    {
         MovePlayer();
         if(Input.GetKeyDown(KeyCode.Space))
        {
            playerAnimator.SetBool("fireState_b", true);
            if (gameObject.GetComponent<SpriteRenderer>().flipX)
            {
                Instantiate(firedBullet, new Vector3(gameObject.transform.position.x - 0.4f, firedBullet.transform.position.y, 0), firedBullet.transform.rotation);
            }
            else
            {
                Instantiate(firedBullet, new Vector3(gameObject.transform.position.x + 0.4f, firedBullet.transform.position.y, 0), firedBullet.transform.rotation);
            }
        }
         else
        {
            playerAnimator.SetBool("fireState_b", false); 
            //print("idle");
        }
    }
    void MovePlayer()
    {
        horizontalInput = Input.GetAxis("Horizontal");
        if (horizontalInput > 0)
        {
            gameObject.GetComponent<SpriteRenderer>().flipX = false;
            playerAnimator.SetBool("walk_b", true);
            transform.Translate(Vector3.right * Time.deltaTime * speedPlayer * horizontalInput);
        }
        else if (horizontalInput < 0)
        {
            gameObject.GetComponent<SpriteRenderer>().flipX = true;
            playerAnimator.SetBool("walk_b", true);
            transform.Translate(Vector3.right * Time.deltaTime * speedPlayer * horizontalInput);
        }
        else
        {
            playerAnimator.SetBool("walk_b", false);
        }


        if (transform.position.x > 7.7f)
        {
            transform.position = new Vector3(7.8f, transform.position.y, 0);
        }
        if (transform.position.x < -7.7f)
        {
            transform.position = new Vector3(-7.8f, transform.position.y, 0);
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(isHitedPlayer)
        {
            isHitedPlayer = false;
            if (UiManager.health >= 10)
            {
                UiManager.health -= 10;
            }
            else
            {
                print("Game Over");
                Time.timeScale = 0f;
            }
        }
        else
        {
            isHitedPlayer = true;
        }
        
    }
}
