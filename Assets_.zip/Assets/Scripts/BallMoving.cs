using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/* First ball randommize in Spawn Manager with Large size
 * When fire hit the ball, increase the score, it destroy the ball and, spawn two ball new balls in firleBullet Script
 * Set postion and Size of new Spawned balls
 * if fire hit ball is tinyBall, then no spawing it.
 * if ball hit the player, drop the player health;
 * 
 * 
 * 
 * 
 *  
*/
public class BallMoving : MonoBehaviour
{
    //Ball Size -> 2 ,1,0.5, 0.25
    private Rigidbody2D ballRb;
    public float ballSize;
    public float forceDirection;
    bool hasFirstCollide;
    // Start is called before the first frame update
    void Start()
    {
        
        ballRb = GetComponent<Rigidbody2D>();
        ballRb.AddForce(new Vector2(Random.Range(3f,6f)*forceDirection, 0),ForceMode2D.Impulse);
        transform.localScale = new Vector2(ballSize, ballSize);
        hasFirstCollide = false;
        
        
    }


    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (!hasFirstCollide)
        {
            if (ballSize >= 2.0f)
            {
                ballRb.GetComponent<Rigidbody2D>().drag = 0.05f;
            }
            else if (ballSize >= 1.0f)
            {
                ballRb.GetComponent<Rigidbody2D>().drag = 0.2f;
            }
            else if (ballSize >= 0.5f)
            {
                ballRb.GetComponent<Rigidbody2D>().drag = 0.4f;
            }
            else
            {
                ballRb.GetComponent<Rigidbody2D>().drag = 0.4f;
            }

            hasFirstCollide = true;

        }
        else
        {
           if (ballSize >= 2.0f)
            {
                ballRb.GetComponent<Rigidbody2D>().drag = 0.015f;
            }
            else if (ballSize >= 1.0f)
            {
                ballRb.GetComponent<Rigidbody2D>().drag = 0.03f;
            }
            else if (ballSize >= 0.5f)
            {
                ballRb.GetComponent<Rigidbody2D>().drag = 0.05f;
            }
            else
            {
                ballRb.GetComponent<Rigidbody2D>().drag = 0.07f;
            }
        }
        if (collision.gameObject.tag == "Ball")
        {
            gameObject.GetComponent<CircleCollider2D>().isTrigger = true;
        }
        if (collision.gameObject.tag == "Boundry")
        {
            gameObject.GetComponent<CircleCollider2D>().isTrigger = false;
        }

    }
    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Ball")
        {
            gameObject.GetComponent<CircleCollider2D>().isTrigger = true;
        }
        if (collision.gameObject.tag == "Boundry")
        {
            gameObject.GetComponent<CircleCollider2D>().isTrigger = false;
        }
    }
}
